﻿###########################################################################
# We recommend to users that download DataM data to subscribe to the newsletter from the home page of the site, in order to be informed by email about possible data corrections or updates.
###########################################################################

Name: EU estimated agricultural balance sheets
Description: A simplified balance sheet to estimate apparent consumption of apples, crops, dairy products, meat, milk, olive oil, oranges and wine, at Member State level. It combines trade data from Eurostat COMEXT database and DG AGRI's short-term outlook for EU agricultural markets to provide historic data on agricultural production, trade and an estimate of apparent use.

DG AGRI, in the Short-term outlook, prepares regularly EU balance sheets for the main agricultural commodities, as well as production, area and yield figures at Member State level, but an estimate of Member States annual consumption was missing, since Eurostat stopped collecting and publishing balance sheets. This dataset fills partially the gap with a rough estimate of apparent use, without detailing the different uses (food, feed, processing), losses or changes in stocks. This apparent use cannot be taken at face value as the consumption level, also because the calculation relies on trade statistics between EU Member States which are less reliable than extra-EU trade figures.

The dataset is updated 3 times per year, at every new release of the DG AGRI Short-term outlook.

The dataset is accompanied by an interactive dashboard, which allows a wide exploration of data. A set of graphs and charts is displayed according to countries, years and products selected by the user. The tool is not only thought to provide average trends, but also to answer specific ad hoc questions on a particular Member State.

User feedback is always welcome to further improve our tool. Please write to JRC-DATAM@ec.europa.eu

Dataset ID: 33243e5e-44a1-4b43-9444-31d64dc7921f

Dimensions: Country, Commodity
Time series: Year (Annual; 2002-2023)
Measures: Apparent use, Apparent use, Apparent use, Apparent use, Apparent use, Apparent per capita use, Apparent per capita use, Apparent per capita use, Apparent per capita use, Beginning stocks, Beginning stocks, Carcass weight, Deliveries, Ending stocks, Ending stocks, Exports (Extra-EU), Exports (Intra-EU), Exports (Extra-EU), Exports (Intra-EU), Exports (Extra-EU), Exports (Intra-EU), Gross indigenous production, Harvested area, Imports (Extra-EU), Imports (Intra-EU), Imports (Extra-EU), Imports (Intra-EU), Imports (Extra-EU), Imports (Intra-EU), Live exports (Extra-EU), Live exports (Intra-EU), Live imports (Extra-EU), Live imports (Intra-EU), Meat exports (Extra-EU), Meat exports (Intra-EU), Meat imports (Extra-EU), Meat imports (Intra-EU), Net production, Net production, Population, Production, Production, Production, Production (from dairy cows), Production of primary product, Self sufficiency, Yield (crops), Yield, Yield (animals), Yield of primary product, Yield of secondary product

File generation date: 11/10/2023 23:01:48
Last data update: 06/10/2023 16:57:57
Number of records: 49093

###################
# GENERAL INFO
###################
Language: English
Main theme: Agriculture, fisheries, forestry and food
Additional theme: Economy and finance
Keywords (comma separated list): production, trade, use, consumption, apparent use, gross indigenous production, GIP. cereals, olive oil, wine, apples, oranges, live animals, meat, milk, dairy products, balance sheets, agriculture, agri-food, EU, EU Member State, EU country, Short-term outlook, DataM, commodity
Issue date: 12/04/2018
Last modified: 06/10/2023 16:57:57
Update frequency: three times a year
Landing page: https://datam.jrc.ec.europa.eu

###################
# DATASET TEMPORAL COVERAGE
###################
Start year: 2002
End year: 2023

###################
# DATASET SPACIAL COVERAGE
###################
Geographic area: European Union
Bounding box W: -31.4647999
Bounding box S: 70.09
Bounding box E: 34.6045
Bounding box N: 27.4985

###################
# DATASET PUBLISHER
###################
Organisation: European Commission, Joint Research Centre (JRC)

###################
# DATASET CONTACT POINT
###################
Email: JRC-DATAM@ec.europa.eu

###################
# CONTRIBUTORS
###################
First name: European Commission
Last name: DG for Agriculture and Rural Development
Email: 
ORCID URL: 

First name: European Commission
Last name: Joint Research Centre
Email: 
ORCID URL: 

###################
# DISTRIBUTIONS
###################
Title: EU estimated agricultural balance sheets
Description: Interactive infographics
Format: text/html
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/mashup/EU_ESTIMATED_AGRICULTURAL_BALANCE_SHEETS

Title: EU estimated agricultural balance sheets (EU-27)
Description: Dataset - Interactive download - CSV format
Format: text/csv
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/33243e5e-44a1-4b43-9444-31d64dc7921f

Title: EU estimated agricultural balance sheets (EU-27)
Description: Dataset - bulk download - zip file with CSV inside
Format: application/zip
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/33243e5e-44a1-4b43-9444-31d64dc7921f/download/Dataset_DG_AGRI-JRC_-_Production__trade_and_apparent_use__EU-27_.zip

###################
# PUBLICATIONS
###################
Title: The EU estimated agricultural balance sheets
Author(s): Caivano, A; Castro Malet, J; Gorrín González, CJ; Porcella-Čapkovičová, A
Publication year: 2023
Publisher: Publications Office of the European Union
Publication URL / DOI URL: https://doi.org/10.2760/278135

###################
# OTHER RESOURCES
###################
Title: EU estimated agricultural balance sheets - Commodity coefficients
Description: Dataset - Interactive download - CSV format
Format: text/csv
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/b6788b6d-bcb1-45fe-97e6-740e3d5a050c

Title: EU estimated agricultural balance sheets - Commodity coefficients
Description: Dataset - bulk download - zip file with CSV inside
Format: application/zip
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/b6788b6d-bcb1-45fe-97e6-740e3d5a050c/download/Dataset_EU_estimated_agricultural_balance_sheets_-_Commodity_coefficients.zip

Title: EU estimated agricultural balance sheets - Milk equivalent coefficients
Description: Dataset - Interactive download - CSV format
Format: text/csv
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/8ead8c24-d214-4366-a3fd-b2e5de768603

Title: EU estimated agricultural balance sheets - Milk equivalent coefficients
Description: Dataset - bulk download - zip file with CSV inside
Format: application/zip
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/8ead8c24-d214-4366-a3fd-b2e5de768603/download/Dataset_EU_estimated_agricultural_balance_sheets_-_Milk_equivalent_coefficients.zip

Title: EU estimated agricultural balance sheets - Retail weight equivalent coefficients
Description: Dataset - Interactive download - CSV format
Format: text/csv
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/04f9a075-4e45-427d-b283-8fa091b12a9a

Title: EU estimated agricultural balance sheets - Retail weight equivalent coefficients
Description: Dataset - bulk download - zip file with CSV inside
Format: application/zip
Access restrictions: No limitations
Licence: European Commission Reuse and Copyright Notice
Licence web: http://ec.europa.eu/geninfo/legal_notices_en.htm
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/perm/dataset/04f9a075-4e45-427d-b283-8fa091b12a9a/download/Dataset_EU_estimated_agricultural_balance_sheets_-_Retail_weight_equivalent_coefficients.zip

Title: Production and yield excel file
Description: The production and yield excel file that was previously available on the STO page is now available in DataM
Format: application/vnd.ms-excel
Access restrictions: No limitations
Licence: European Union Public Licence v. 1.2
Licence web: https://joinup.ec.europa.eu/collection/eupl/eupl-guidelines-faq-infographics
Download URL / DOI URL: https://datam.jrc.ec.europa.eu/datam/mashup/BALANCE_SHEETS_PRODUCTION_DATA_FILE/

